<?php
/*mysql_select_db('rms',mysql_connect('localhost','root',''))or die(mysql_error());*/
?>

<?php
$con=mysqli_connect("localhost","bryan","password","rms");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }



?>